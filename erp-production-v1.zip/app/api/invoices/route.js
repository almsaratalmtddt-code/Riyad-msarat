import {NextResponse} from "next/server"; import {prisma} from "../../../lib/prisma";
export async function GET(){return NextResponse.json(await prisma.invoice.findMany({include:{customer:true,lines:{include:{product:true}}},orderBy:{date:"desc"}}))}
export async function POST(req){
 const b=await req.json(); if(!b.lines?.length)return NextResponse.json({error:"الفاتورة بدون أصناف"},{status:400});
 const subtotal=b.lines.reduce((s,x)=>s+Number(x.qty)*Number(x.price),0), tax=Number(b.tax||0), total=subtotal+tax, paid=Number(b.paid||0);
 if(paid>total)return NextResponse.json({error:"المدفوع أكبر من الإجمالي"},{status:400});
 const number="SO-"+Date.now().toString().slice(-8);
 const invoice=await prisma.$transaction(async tx=>{
  const inv=await tx.invoice.create({data:{number,customerId:b.customerId||null,status:paid>=total?"PAID":"CONFIRMED",subtotal,tax,total,paid,due:total-paid,lines:{create:b.lines.map(x=>({productId:x.productId,qty:x.qty,price:x.price,total:Number(x.qty)*Number(x.price)}))}}});
  for(const x of b.lines){await tx.product.update({where:{id:x.productId},data:{stock:{decrement:x.qty}}});}
  if(paid>0) await tx.payment.create({data:{amount:paid,method:b.method||"CASH",invoiceId:inv.id,customerId:b.customerId||null}});
  return inv;
 }); return NextResponse.json(invoice,{status:201});
}