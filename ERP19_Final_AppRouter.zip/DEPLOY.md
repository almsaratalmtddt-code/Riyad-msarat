# ERP 19

هذه النسخة رتبت Next.js App Router بالشكل الصحيح:
- app/page.jsx
- app/layout.jsx
- app/style.css
- package.json

ارفع الملفات إلى مستودع GitHub الحالي ثم سيقوم Vercel بإعادة البناء تلقائياً.
